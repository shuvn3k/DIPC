echo OK: Everything is going to be fine
exit 0